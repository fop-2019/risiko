package tests.student;

public class GraphConnectionTest {

}
