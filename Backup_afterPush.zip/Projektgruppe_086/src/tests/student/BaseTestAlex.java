package tests.student;

import java.util.Arrays;
import org.junit.Test;
import static org.junit.Assert.*;

// tests für base


public class BaseTestAlex {
	
	
	
	

}
