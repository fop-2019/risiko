package gui.components;

public interface ValueListener {

    void valueChanged(Object oldValue, Object newValue);
}
